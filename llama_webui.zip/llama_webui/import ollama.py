import subprocess

def list_ollama_models():
    try:
        # Run the 'ollama list' (or correct command based on help) command and capture the output
        result = subprocess.run(['ollama', 'list'], capture_output=True, text=True)
        
        # Check if the command was successful
        if result.returncode == 0:
            print("Available Ollama Models:")
            print(result.stdout)
        else:
            print(f"Error: {result.stderr}")
    
    except FileNotFoundError:
        print("Ollama CLI is not installed or not found in your PATH.")
    except Exception as e:
        print(f"An error occurred: {str(e)}")

# Call the function
list_ollama_models()
