from flask import Flask, render_template, request
import ollama

app = Flask(__name__)

# Initialize the Llama2 model (you can change this if needed)
model = ollama

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/ask', methods=['POST'])
def ask():
    user_input = request.form['user_input']
    response = model.chat(model="llama2", messages=[{"role": "user", "content": user_input}])
    return render_template('index.html', response=response['text'], user_input=user_input)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000, debug=True)